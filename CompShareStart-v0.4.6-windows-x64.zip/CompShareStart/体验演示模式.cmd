@echo off
cd /d "%~dp0"
start "" "CompShareStart.exe" --demo
